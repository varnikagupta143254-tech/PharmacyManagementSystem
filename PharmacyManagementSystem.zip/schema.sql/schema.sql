-- Pharmacy Management System - database script
-- Run this once on a new MySQL server (local XAMPP or cloud).

CREATE DATABASE IF NOT EXISTS pharmacy_db;
USE pharmacy_db;

CREATE TABLE IF NOT EXISTS medicine (
  medicine_id   INT PRIMARY KEY AUTO_INCREMENT,
  medicine_name VARCHAR(100) NOT NULL,
  category      VARCHAR(50),
  quantity      INT,
  price         DOUBLE,
  expiry_date   DATE
);

CREATE TABLE IF NOT EXISTS supplier (
  id      INT PRIMARY KEY AUTO_INCREMENT,
  name    VARCHAR(100) NOT NULL,
  contact VARCHAR(15),
  address VARCHAR(200)
);

CREATE TABLE IF NOT EXISTS customer (
  id      INT PRIMARY KEY AUTO_INCREMENT,
  name    VARCHAR(100) NOT NULL,
  phone   VARCHAR(15),
  address VARCHAR(200)
);

CREATE TABLE IF NOT EXISTS sales (
  id           INT PRIMARY KEY AUTO_INCREMENT,
  medicine_id  INT,
  customer_id  INT,
  quantity     INT NOT NULL,
  sale_date    DATE,
  total_amount DECIMAL(10,2),
  FOREIGN KEY (medicine_id) REFERENCES medicine(medicine_id),
  FOREIGN KEY (customer_id) REFERENCES customer(id)
);

CREATE TABLE IF NOT EXISTS users (
  user_id  INT PRIMARY KEY AUTO_INCREMENT,
  username VARCHAR(50) UNIQUE NOT NULL,
  password VARCHAR(64) NOT NULL,
  role     VARCHAR(20) DEFAULT 'admin'
);

-- Demo login: admin / admin123 (password stored as SHA-256 hash)
INSERT INTO users (username, password)
SELECT 'admin', SHA2('admin123', 256)
WHERE NOT EXISTS (SELECT 1 FROM users WHERE username = 'admin');

-- Sample medicines
INSERT INTO medicine (medicine_name, category, quantity, price, expiry_date) VALUES
  ('Paracetamol', 'Tablet',  100, 20.5, '2027-05-20'),
  ('Amoxicillin', 'Capsule',  50, 45,   '2027-08-15'),
  ('Cough Syrup', 'Syrup',    30, 80,   '2027-03-10');
