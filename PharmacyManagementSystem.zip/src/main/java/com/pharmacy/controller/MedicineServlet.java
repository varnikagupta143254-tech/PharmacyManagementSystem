package com.pharmacy.controller;

import com.pharmacy.dao.MedicineDAO;
import com.pharmacy.model.Medicine;
import java.io.IOException;
import java.sql.Date;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/medicine")
public class MedicineServlet extends HttpServlet {

    private final MedicineDAO dao = new MedicineDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        if (action == null) action = "list";

        try {
            switch (action) {
                case "new":
                    request.getRequestDispatcher("medicine_form.jsp").forward(request, response);
                    break;
                case "edit":
                    int editId = Integer.parseInt(request.getParameter("id"));
                    request.setAttribute("medicine", dao.getMedicineById(editId));
                    request.getRequestDispatcher("medicine_form.jsp").forward(request, response);
                    break;
                case "delete":
                    dao.deleteMedicine(Integer.parseInt(request.getParameter("id")));
                    response.sendRedirect("medicine?msg=Medicine+deleted+successfully");
                    break;
                default:
                    request.setAttribute("medicines", dao.getAllMedicines());
                    request.setAttribute("msg", request.getParameter("msg"));
                    request.getRequestDispatcher("medicine_list.jsp").forward(request, response);
            }
        } catch (SQLException | NumberFormatException e) {
            e.printStackTrace();
            request.setAttribute("error", "Operation failed: " + e.getMessage());
            request.getRequestDispatcher("medicine_list.jsp").forward(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String idStr = request.getParameter("id");
        String name = request.getParameter("name");
        String category = request.getParameter("category");
        String quantityStr = request.getParameter("quantity");
        String priceStr = request.getParameter("price");
        String expiryStr = request.getParameter("expiryDate");

        // ---------- Server-side validation ----------
        String error = null;
        int quantity = 0;
        double price = 0;
        Date expiry = null;

        try {
            if (name == null || name.trim().isEmpty()) {
                error = "Medicine name is required.";
            } else if (category == null || category.trim().isEmpty()) {
                error = "Category is required.";
            } else {
                quantity = Integer.parseInt(quantityStr);
                price = Double.parseDouble(priceStr);
                if (quantity < 0) {
                    error = "Quantity cannot be negative.";
                } else if (price <= 0) {
                    error = "Price must be greater than 0.";
                } else {
                    LocalDate exp = LocalDate.parse(expiryStr);
                    if (exp.isBefore(LocalDate.now())) {
                        error = "Expiry date cannot be in the past.";
                    } else {
                        expiry = Date.valueOf(exp);
                    }
                }
            }
        } catch (NumberFormatException e) {
            error = "Quantity and price must be valid numbers.";
        } catch (DateTimeParseException | NullPointerException e) {
            error = "Please enter a valid expiry date.";
        }

        Medicine m = new Medicine();
        if (idStr != null && !idStr.isEmpty()) m.setId(Integer.parseInt(idStr));
        m.setName(name);
        m.setCategory(category);
        m.setQuantity(quantity);
        m.setPrice(price);
        m.setExpiryDate(expiry);

        if (error != null) {
            request.setAttribute("error", error);
            request.setAttribute("medicine", m);
            request.getRequestDispatcher("medicine_form.jsp").forward(request, response);
            return;
        }

        // ---------- Save ----------
        try {
            if (idStr != null && !idStr.isEmpty()) {
                dao.updateMedicine(m);
                response.sendRedirect("medicine?msg=Medicine+updated+successfully");
            } else {
                dao.addMedicine(m);
                response.sendRedirect("medicine?msg=Medicine+added+successfully");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "Database error: " + e.getMessage());
            request.setAttribute("medicine", m);
            request.getRequestDispatcher("medicine_form.jsp").forward(request, response);
        }
    }
}