package com.pharmacy.dao;

import com.pharmacy.model.Medicine;
import com.pharmacy.util.DBConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MedicineDAO {

    private Medicine map(ResultSet rs) throws SQLException {
        return new Medicine(
            rs.getInt("medicine_id"),
            rs.getString("medicine_name"),
            rs.getString("category"),
            rs.getInt("quantity"),
            rs.getDouble("price"),
            rs.getDate("expiry_date"));
    }

    public List<Medicine> getAllMedicines() throws SQLException {
        List<Medicine> list = new ArrayList<>();
        String sql = "SELECT * FROM medicine";
        try (Connection con = DBConnection.getConnection();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) list.add(map(rs));
        }
        return list;
    }

    public Medicine getMedicineById(int id) throws SQLException {
        String sql = "SELECT * FROM medicine WHERE medicine_id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return map(rs);
            }
        }
        return null;
    }

    public void addMedicine(Medicine m) throws SQLException {
        String sql = "INSERT INTO medicine (medicine_name, category, quantity, price, expiry_date) VALUES (?, ?, ?, ?, ?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, m.getName());
            ps.setString(2, m.getCategory());
            ps.setInt(3, m.getQuantity());
            ps.setDouble(4, m.getPrice());
            ps.setDate(5, m.getExpiryDate());
            ps.executeUpdate();
        }
    }

    public void updateMedicine(Medicine m) throws SQLException {
        String sql = "UPDATE medicine SET medicine_name=?, category=?, quantity=?, price=?, expiry_date=? WHERE medicine_id=?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, m.getName());
            ps.setString(2, m.getCategory());
            ps.setInt(3, m.getQuantity());
            ps.setDouble(4, m.getPrice());
            ps.setDate(5, m.getExpiryDate());
            ps.setInt(6, m.getId());
            ps.executeUpdate();
        }
    }

    public void deleteMedicine(int id) throws SQLException {
        String sql = "DELETE FROM medicine WHERE medicine_id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }
}