<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Pharmacy Login</title>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background: linear-gradient(135deg, #e0f7fa 0%, #e8f5e9 100%);
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .login-card {
            background-color: #ffffff;
            padding: 40px 35px;
            border-radius: 12px;
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 380px;
            border-top: 5px solid #00897b; /* Medical Teal accent */
        }

        .login-card h2 {
            text-align: center;
            color: #00695c;
            margin-bottom: 20px;
            font-size: 24px;
            font-weight: 600;
        }

        .alert-msg {
            background-color: #ffebee;
            color: #c62828;
            border: 1px solid #ef9a9a;
            padding: 10px 12px;
            border-radius: 6px;
            font-size: 14px;
            text-align: center;
            margin-bottom: 20px;
        }

        .form-group {
            margin-bottom: 18px;
        }

        .form-group label {
            display: block;
            margin-bottom: 6px;
            color: #37474f;
            font-size: 14px;
            font-weight: 500;
        }

        .form-group input[type="text"],
        .form-group input[type="password"] {
            width: 100%;
            padding: 11px 14px;
            border: 1px solid #cfd8dc;
            border-radius: 6px;
            font-size: 15px;
            transition: border-color 0.3s ease;
        }

        .form-group input[type="text"]:focus,
        .form-group input[type="password"]:focus {
            outline: none;
            border-color: #00897b;
            box-shadow: 0 0 0 3px rgba(0, 137, 123, 0.15);
        }

        .btn-login {
            width: 100%;
            padding: 12px;
            background-color: #00897b;
            color: white;
            border: none;
            border-radius: 6px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: background-color 0.3s ease;
            margin-top: 5px;
        }

        .btn-login:hover {
            background-color: #00695c;
        }
    </style>
</head>
<body>

    <div class="login-card">
        <h2>Pharmacy Login</h2>

        <%-- Displays the ?msg= parameter from the URL cleanly --%>
        <% 
            String msg = request.getParameter("msg");
            if (msg != null && !msg.trim().isEmpty()) { 
        %>
            <div class="alert-msg"><%= msg %></div>
        <% } %>

        <!-- Make sure the 'action' matches your existing servlet or JSP file -->
        <form action="login" method="post">
            <div class="form-group">
                <label for="username">Username</label>
                <!-- Make sure 'name' matches what your backend expects -->
                <input type="text" id="username" name="username" placeholder="Enter your username" required>
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <!-- Make sure 'name' matches what your backend expects -->
                <input type="password" id="password" name="password" placeholder="Enter your password" required>
            </div>

            <button type="submit" class="btn-login">Login</button>
        </form>
    </div>

</body>
</html>