<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html>
<head>
    <title>Medicine List</title>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: #f4f7f6;
            color: #37474f;
            padding: 30px;
        }

        .container {
            max-width: 1100px;
            margin: 0 auto;
            background-color: #ffffff;
            padding: 30px 35px;
            border-radius: 12px;
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.06);
            border-top: 5px solid #00897b;
        }

        .userbar {
            text-align: right;
            font-size: 14px;
            color: #546e7a;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 1px solid #eceff1;
        }

        .userbar a {
            color: #e53935;
            text-decoration: none;
            font-weight: 600;
            margin-left: 5px;
        }

        h2 {
            color: #00695c;
            margin-bottom: 18px;
            font-size: 24px;
        }

        .success {
            background-color: #e8f5e9;
            color: #2e7d32;
            border: 1px solid #a5d6a7;
            padding: 10px 14px;
            border-radius: 6px;
            margin-bottom: 16px;
            font-size: 14px;
        }

        .error {
            background-color: #ffebee;
            color: #c62828;
            border: 1px solid #ef9a9a;
            padding: 10px 14px;
            border-radius: 6px;
            margin-bottom: 16px;
            font-size: 14px;
        }

        .btn {
            display: inline-block;
            background-color: #00897b;
            color: #ffffff;
            padding: 9px 16px;
            border-radius: 6px;
            font-size: 14px;
            font-weight: 500;
            text-decoration: none;
            margin-right: 8px;
            transition: background-color 0.25s ease;
        }

        .btn:hover {
            background-color: #00695c;
        }

        .btn.green {
            background-color: #2e7d32;
        }

        .btn.green:hover {
            background-color: #1b5e20;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th {
            background-color: #00695c;
            color: #ffffff;
            text-align: left;
            padding: 13px 15px;
            font-size: 14px;
        }

        td {
            padding: 12px 15px;
            border-bottom: 1px solid #eceff1;
            font-size: 14px;
        }

        tr:nth-child(even) {
            background-color: #f8fbfb;
        }

        tr:hover {
            background-color: #e0f2f1;
        }

        td a {
            padding: 5px 10px;
            border-radius: 4px;
            font-size: 13px;
            text-decoration: none;
            font-weight: 500;
            margin-right: 6px;
            background-color: #e0f2f1;
            color: #00695c;
        }

        td a[href*="delete"] {
            background-color: #ffebee;
            color: #c62828;
        }
    </style>
</head>
<body>
<div class="container">
    <p class="userbar">Logged in as <b>${sessionScope.username}</b> | <a href="logout">Logout</a></p>
    <h2>Medicine List</h2>

    <c:if test="${not empty msg}"><p class="success">${msg}</p></c:if>
    <c:if test="${not empty error}"><p class="error">${error}</p></c:if>

    <a class="btn green" href="medicine?action=new">+ Add Medicine</a>
    <a class="btn" href="index.jsp">Home</a>

    <table>
        <tr>
            <th>ID</th><th>Name</th><th>Category</th>
            <th>Quantity</th><th>Price</th><th>Expiry Date</th><th>Actions</th>
        </tr>
        <c:forEach var="m" items="${medicines}">
            <tr>
                <td>${m.id}</td>
                <td>${m.name}</td>
                <td>${m.category}</td>
                <td>${m.quantity}</td>
                <td>${m.price}</td>
                <td>${m.expiryDate}</td>
                <td>
                    <a href="medicine?action=edit&id=${m.id}">Edit</a> |
                    <a href="medicine?action=delete&id=${m.id}"
                       onclick="return confirm('Delete this medicine?');">Delete</a>
                </td>
            </tr>
        </c:forEach>
        <c:if test="${empty medicines}">
            <tr><td colspan="7">No medicines found.</td></tr>
        </c:if>
    </table>
</div>
</body>
</html>