<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Dashboard - Pharmacy Management System</title>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: #f4f7f6;
            color: #37474f;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        .navbar {
            background-color: #00695c;
            color: #ffffff;
            padding: 16px 40px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.12);
        }

        .navbar-brand {
            font-size: 20px;
            font-weight: 600;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
            font-size: 14px;
        }

        .btn-logout {
            background-color: #e53935;
            color: #ffffff;
            text-decoration: none;
            padding: 7px 14px;
            border-radius: 5px;
            font-weight: 500;
        }

        .btn-logout:hover {
            background-color: #c62828;
        }

        .container {
            max-width: 900px;
            width: 90%;
            margin: 50px auto;
            background-color: #ffffff;
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.06);
            border-top: 5px solid #00897b;
        }

        .welcome-header h1 {
            color: #00695c;
            font-size: 28px;
            margin-bottom: 8px;
        }

        .welcome-header p {
            color: #607d8b;
            font-size: 16px;
            margin-bottom: 32px;
        }

        .action-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
            gap: 20px;
        }

        .action-card {
            display: block;
            text-decoration: none;
            background-color: #f8fbfb;
            border: 1px solid #cfd8dc;
            border-left: 5px solid #00897b;
            border-radius: 8px;
            padding: 24px;
            transition: all 0.25s ease;
        }

        .action-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 18px rgba(0, 137, 123, 0.15);
            border-color: #00897b;
            background-color: #ffffff;
        }

        .action-card h3 {
            color: #00695c;
            font-size: 18px;
            margin-bottom: 8px;
        }

        .action-card p {
            color: #546e7a;
            font-size: 14px;
            line-height: 1.4;
        }
    </style>
</head>
<body>

    <nav class="navbar">
        <div class="navbar-brand">Pharmacy Management System</div>
        <div class="user-info">
            <span>Logged in as <strong>${sessionScope.username != null ? sessionScope.username : 'admin'}</strong></span>
            <a href="logout" class="btn-logout">Logout</a>
        </div>
    </nav>

    <div class="container">
        <div class="welcome-header">
            <h1>Pharmacy Management System</h1>
            <p>Manage your medicine inventory easily.</p>
        </div>

        <div class="action-grid">
            <a href="medicine" class="action-card">
                <h3>View Medicines</h3>
                <p>Browse, search, update, or remove existing medicines in your pharmacy stock.</p>
            </a>

            <a href="medicine?form.jsp" class="action-card">
                <h3>Add New Medicine</h3>
                <p>Register new medicine batches, pricing, and stock quantities into the system.</p>
            </a>
        </div>
    </div>

</body>
</html>