<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html>
<head>
    <title>Medicine Form</title>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: #f4f7f6;
            color: #37474f;
            padding: 30px;
        }

        .container {
            max-width: 550px;
            margin: 20px auto;
            background-color: #ffffff;
            padding: 35px 40px;
            border-radius: 12px;
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.06);
            border-top: 5px solid #00897b;
        }

        .userbar {
            text-align: right;
            font-size: 14px;
            color: #546e7a;
            margin-bottom: 18px;
            padding-bottom: 10px;
            border-bottom: 1px solid #eceff1;
        }

        .userbar a {
            color: #e53935;
            text-decoration: none;
            font-weight: 600;
            margin-left: 5px;
        }

        h2 {
            color: #00695c;
            margin-bottom: 22px;
            font-size: 24px;
        }

        .error {
            background-color: #ffebee;
            color: #c62828;
            border: 1px solid #ef9a9a;
            padding: 10px 14px;
            border-radius: 6px;
            margin-bottom: 16px;
            font-size: 14px;
        }

        form label {
            display: block;
            margin-top: 14px;
            margin-bottom: 6px;
            color: #37474f;
            font-size: 14px;
            font-weight: 500;
        }

        form input[type="text"],
        form input[type="number"],
        form input[type="date"],
        form select {
            width: 100%;
            padding: 10px 12px;
            border: 1px solid #cfd8dc;
            border-radius: 6px;
            font-size: 15px;
            margin-bottom: 6px;
            transition: border-color 0.25s ease;
        }

        form input:focus,
        form select:focus {
            outline: none;
            border-color: #00897b;
            box-shadow: 0 0 0 3px rgba(0, 137, 123, 0.15);
        }

        form button,
        form input[type="submit"],
        .btn {
            display: inline-block;
            background-color: #00897b;
            color: #ffffff;
            padding: 10px 20px;
            border: none;
            border-radius: 6px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            margin-top: 20px;
            margin-right: 10px;
            transition: background-color 0.25s ease;
        }

        form button:hover,
        form input[type="submit"]:hover,
        .btn:hover {
            background-color: #00695c;
        }

        form a {
            display: inline-block;
            background-color: #eceff1;
            color: #455a64;
            padding: 10px 18px;
            border-radius: 6px;
            font-size: 15px;
            font-weight: 500;
            text-decoration: none;
            margin-top: 20px;
            transition: background-color 0.25s ease;
        }

        form a:hover {
            background-color: #cfd8dc;
        }
    </style>
    <script>
        function validateForm() {
            var f = document.forms["medForm"];
            var name = f["name"].value.trim();
            var qty = f["quantity"].value;
            var price = f["price"].value;
            var expiry = f["expiryDate"].value;

            if (name === "") { alert("Medicine name is required."); return false; }
            if (qty === "" || qty < 0) { alert("Quantity must be 0 or more."); return false; }
            if (price === "" || price <= 0) { alert("Price must be greater than 0."); return false; }
            if (expiry === "" || new Date(expiry) < new Date()) {
                alert("Expiry date must be a future date."); return false;
            }
            return true;
        }
    </script>
</head>
<body>
<div class="container">
    <p class="userbar">Logged in as <b>${sessionScope.username}</b> | <a href="logout">Logout</a></p>
    <h2><c:choose><c:when test="${medicine.id > 0}">Edit Medicine</c:when><c:otherwise>Add New Medicine</c:otherwise></c:choose></h2>

    <c:if test="${not empty error}"><p class="error">${error}</p></c:if>

    <form name="medForm" action="medicine" method="post" onsubmit="return validateForm()">
        <input type="hidden" name="id" value="${medicine.id > 0 ? medicine.id : ''}">

        <label>Name</label>
        <input type="text" name="name" value="${medicine.name}" required>

        <label>Category</label>
        <input type="text" name="category" value="${medicine.category}" required>

        <label>Quantity</label>
        <input type="number" name="quantity" min="0" value="${medicine.quantity}" required>

        <label>Price</label>
        <input type="number" step="0.01" name="price" min="0.01" value="${medicine.price}" required>

        <label>Expiry Date</label>
        <input type="date" name="expiryDate" value="${medicine.expiryDate}" required>

        <input type="submit" class="btn green" value="Save">
        <a class="btn" href="medicine">Cancel</a>
    </form>
</div>
</body>
</html>