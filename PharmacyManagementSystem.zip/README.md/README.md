# Pharmacy Management System

A web-based pharmacy inventory application built for the **Advanced Java Technologies (01CE0308)** course at Marwadi University.
It lets an authorised user log in and add, view, edit and delete medicines.

**Live demo:** https://YOUR-APP-NAME.onrender.com  
**Demo login:** `admin` / `admin123`  
> The free host may put the app to sleep when it is idle, so the first load can take a minute.

## Features
- Login and logout with session management (`HttpSession`) and a servlet filter that protects every page
- Passwords stored as SHA-256 hashes, not plain text
- Create, read, update and delete (CRUD) operations on medicines
- Client-side (JavaScript/HTML5) and server-side form validation
- Success and error messages, styled pages with CSS

## Technologies
| Area | Technology |
|---|---|
| Controller | Java Servlets, Servlet Filter |
| View | JSP, JSTL, Expression Language, HTML, CSS, JavaScript |
| Session | HttpSession, `JSESSIONID` cookie |
| Data access | JDBC (`PreparedStatement`), DAO pattern |
| Database | MySQL |
| Server / build | Apache Tomcat 9, Maven, NetBeans |

## Layered architecture
```
Browser -> AuthFilter -> MedicineServlet / LoginServlet / LogoutServlet (controller)
        -> MedicineDAO / UserDAO (data access) -> DBConnection -> MySQL
        -> JSP + JSTL (view)
```

```
src/main/java/com/pharmacy
  controller/  MedicineServlet, LoginServlet, LogoutServlet
  dao/         MedicineDAO, UserDAO
  model/       Medicine
  util/        DBConnection
  filter/      AuthFilter
src/main/webapp
  index.jsp, login.jsp, medicine_list.jsp, medicine_form.jsp, css/style.css
schema.sql     database script
Dockerfile     container build for deployment
```

## Run locally (XAMPP + NetBeans)
1. Start **Apache** and **MySQL** in XAMPP.
2. Open phpMyAdmin, go to the **SQL** tab, paste the contents of `schema.sql` and click **Go**.
3. Open the project in NetBeans (Maven web project) and run it on **Tomcat 9**.
4. Open `http://localhost:8080/PharmacyManagementSystem/` (use your Tomcat port) and log in with `admin` / `admin123`.

The app connects to `jdbc:mysql://127.0.0.1:3306/pharmacy_db` with user `root` and an empty password by default.

## Configuration (for deployment)
The database settings can be changed with environment variables, so no password is stored in the code:

| Variable | Meaning | Example |
|---|---|---|
| `DB_URL` | JDBC URL | `jdbc:mysql://host:4000/pharmacy_db?sslMode=VERIFY_IDENTITY` |
| `DB_USER` | Database user | `xxxx.root` |
| `DB_PASS` | Database password | (set on the hosting dashboard) |

## Run with Docker
```bash
docker build -t pharmacy-app .
docker run -p 8080:8080 -e DB_URL=... -e DB_USER=... -e DB_PASS=... pharmacy-app
```

## Screenshots
Add screenshots of the login page, medicine list and add form here.

## Authors
- Varnika Gupta (92500119160)
- Samarth Math (92500119034)

CSE-CS, Semester 3, Marwadi University
